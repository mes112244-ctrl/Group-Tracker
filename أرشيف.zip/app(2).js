const STORAGE_KEY = "behavior_tracker_v1";
const defaults = {
  settings:{school:"الثانوية الرابعة بالقطيف – مسارات",teacher:"زهراء آل سليم",principal:"وفاء القديحي",year:"1448هـ"},
  classes:["2/1","2/2","2/3"],
  students:[],
  criteria:[
    {id:"c1",name:"الانضباط",points:5,icon:"shield-check"},
    {id:"c2",name:"المشاركة الفاعلة",points:5,icon:"hand"},
    {id:"c3",name:"التعاون",points:5,icon:"users-round"},
    {id:"c4",name:"المبادرة",points:10,icon:"rocket"},
    {id:"c5",name:"الاحترام",points:5,icon:"heart-handshake"},
    {id:"c6",name:"التميز الدراسي",points:10,icon:"graduation-cap"}
  ],
  records:[]
};
let state = load();
let selectedCriterion = state.criteria[0]?.id || null;
let chart;

function load(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw) return structuredClone(defaults);
    const x = JSON.parse(raw);
    return {...structuredClone(defaults), ...x, settings:{...defaults.settings,...x.settings}};
  }catch{return structuredClone(defaults)}
}
function save(){localStorage.setItem(STORAGE_KEY,JSON.stringify(state))}
function id(){return "id_"+Date.now()+"_"+Math.random().toString(36).slice(2,7)}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[m]))}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function score(studentId){return state.records.filter(r=>r.studentId===studentId).reduce((a,b)=>a+(+b.points||0),0)}
function recCount(studentId){return state.records.filter(r=>r.studentId===studentId).length}
function studentById(x){return state.students.find(s=>s.id===x)}
function criterionById(x){return state.criteria.find(c=>c.id===x)}
function today(){return new Date().toISOString().slice(0,10)}

const titles={dashboard:"لوحة التحكم",students:"إدارة الطالبات",record:"رصد السلوك المتميز",top:"الطالبات المتميزات",reports:"التقارير",criteria:"معايير السلوك",certificates:"شهادات التميز",settings:"الإعدادات"};
function goPage(p){
  document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));
  document.getElementById("page-"+p).classList.add("active");
  document.querySelectorAll(".nav-link").forEach(x=>x.classList.toggle("active",x.dataset.page===p));
  document.getElementById("pageTitle").textContent=titles[p];
  document.getElementById("sidebar").classList.remove("open");
  renderAll();
  lucide.createIcons();
}
window.goPage=goPage;

function renderAll(){
  applySettings(); fillClassSelects(); renderStudents(); renderCriteriaPicker(); renderRecent(); renderDashboard(); renderTop(); renderReports(); renderCriteriaManage(); renderCertificate();
}
function applySettings(){
  const s=state.settings;
  ["brandSchool","reportSchool","certSchool"].forEach(i=>document.getElementById(i).textContent=s.school);
  document.getElementById("reportTeacher").textContent=s.teacher;document.getElementById("reportPrincipal").textContent=s.principal;
  document.getElementById("certTeacher").textContent=s.teacher;document.getElementById("certPrincipal").textContent=s.principal;
  document.getElementById("settingSchool").value=s.school;document.getElementById("settingTeacher").value=s.teacher;document.getElementById("settingPrincipal").value=s.principal;document.getElementById("settingYear").value=s.year;
}
function fillClassSelects(){
  const ids=["studentClassFilter","recordClass","reportClass","certClass"];
  ids.forEach(k=>{
    const el=document.getElementById(k);const prev=el.value;
    const all=(k==="studentClassFilter"||k==="reportClass")?'<option value="">كل الفصول</option>':'';
    el.innerHTML=all+state.classes.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join("");
    if([...el.options].some(o=>o.value===prev)) el.value=prev;
  });
  fillStudentsForRecord(); fillReportStudents(); fillCertStudents();
}
function fillStudentsForRecord(){
  const c=document.getElementById("recordClass").value;
  const st=state.students.filter(s=>!c||s.className===c);
  const el=document.getElementById("recordStudent");const prev=el.value;
  el.innerHTML=st.length?st.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join(""):'<option value="">لا توجد طالبات</option>';
  if(st.some(s=>s.id===prev))el.value=prev;
}
function fillReportStudents(){
  const c=document.getElementById("reportClass").value;
  const el=document.getElementById("reportStudent");const prev=el.value;
  const arr=state.students.filter(s=>!c||s.className===c);
  el.innerHTML='<option value="">كل الطالبات</option>'+arr.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join("");
  if(arr.some(s=>s.id===prev)) el.value=prev;
}
function fillCertStudents(){
  const c=document.getElementById("certClass").value;
  const arr=state.students.filter(s=>!c||s.className===c);const el=document.getElementById("certStudent");const prev=el.value;
  el.innerHTML=arr.length?arr.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join(""):'<option value="">لا توجد طالبات</option>';
  if(arr.some(s=>s.id===prev)) el.value=prev;
  renderCertificate();
}
function renderStudents(){
  const q=document.getElementById("studentSearch").value.trim();
  const c=document.getElementById("studentClassFilter").value;
  const arr=state.students.filter(s=>(!c||s.className===c)&&(!q||s.name.includes(q)));
  const tbody=document.getElementById("studentsTable");
  tbody.innerHTML=arr.map((s,i)=>`<tr><td>${i+1}</td><td><b>${esc(s.name)}</b></td><td>${esc(s.className)}</td><td>${score(s.id)}</td><td>${recCount(s.id)}</td><td><div class="row-actions"><button class="mini-btn" onclick="editStudent('${s.id}')"><i data-lucide="pencil"></i></button><button class="mini-btn danger" onclick="deleteStudent('${s.id}')"><i data-lucide="trash-2"></i></button></div></td></tr>`).join("");
  document.getElementById("studentsEmpty").classList.toggle("hidden",arr.length>0);
}
function renderCriteriaPicker(){
  const box=document.getElementById("criteriaPicker");
  box.innerHTML=state.criteria.map(c=>`<button class="criterion-option ${selectedCriterion===c.id?"selected":""}" onclick="selectCriterion('${c.id}')"><span class="ico"><i data-lucide="${esc(c.icon)}"></i></span><span><b>${esc(c.name)}</b><span>${c.points} نقاط</span></span></button>`).join("");
}
window.selectCriterion=function(x){selectedCriterion=x;renderCriteriaPicker();lucide.createIcons()}
function renderRecent(){
  const box=document.getElementById("recentRecords");
  const arr=[...state.records].sort((a,b)=>(b.date+b.id).localeCompare(a.date+a.id)).slice(0,8);
  box.innerHTML=arr.length?arr.map(r=>{const s=studentById(r.studentId),c=criterionById(r.criterionId);return `<div class="activity"><span class="ico"><i data-lucide="${c?.icon||"star"}"></i></span><div><b>${esc(s?.name||"طالبة محذوفة")}</b><small>${esc(c?.name||"معيار محذوف")} • ${esc(r.date)}${r.note?" • "+esc(r.note):""}</small></div><div><span class="activity-points">+${r.points}</span> <button class="mini-btn danger" onclick="deleteRecord('${r.id}')"><i data-lucide="x"></i></button></div></div>`}).join(""):'<div class="empty"><p>لا توجد عمليات رصد بعد.</p></div>';
}
function renderDashboard(){
  document.getElementById("statStudents").textContent=state.students.length;
  document.getElementById("statRecords").textContent=state.records.length;
  document.getElementById("statClasses").textContent=state.classes.length;
  document.getElementById("statTop").textContent=state.students.filter(s=>score(s.id)>=20).length;
  const top=[...state.students].sort((a,b)=>score(b.id)-score(a.id)).slice(0,5);
  document.getElementById("topMiniList").innerHTML=top.length?top.map((s,i)=>`<div class="rank-item"><span class="rank-no">${i+1}</span><div class="rank-info"><b>${esc(s.name)}</b><span>${esc(s.className)}</span></div><span class="rank-points">${score(s.id)} نقطة</span></div>`).join(""):'<div class="empty"><p>أضيفي الطالبات وابدئي الرصد.</p></div>';
  const labels=state.criteria.map(c=>c.name); const data=state.criteria.map(c=>state.records.filter(r=>r.criterionId===c.id).length);
  const ctx=document.getElementById("behaviorChart");
  if(chart) chart.destroy();
  chart=new Chart(ctx,{type:"bar",data:{labels,datasets:[{label:"عدد الرصدات",data,borderWidth:0,borderRadius:8,backgroundColor:"#6d6de2"}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{precision:0}},x:{grid:{display:false}}}}});
}
function renderTop(){
  const arr=[...state.students].sort((a,b)=>score(b.id)-score(a.id));
  document.getElementById("topStudentsGrid").innerHTML=arr.length?arr.map((s,i)=>`<div class="card top-card"><div class="avatar"><i data-lucide="${i<3?"crown":"user"}"></i></div><h4>${esc(s.name)}</h4><p>${esc(s.className)} • ${recCount(s.id)} رصد</p><span class="points-pill">${score(s.id)} نقطة</span></div>`).join(""):'<div class="card empty"><p>لا توجد بيانات بعد.</p></div>';
}
function filteredRecords(){
  const c=document.getElementById("reportClass").value, sid=document.getElementById("reportStudent").value, f=document.getElementById("reportFrom").value, t=document.getElementById("reportTo").value;
  return state.records.filter(r=>{const s=studentById(r.studentId);return (!c||s?.className===c)&&(!sid||r.studentId===sid)&&(!f||r.date>=f)&&(!t||r.date<=t)});
}
function renderReports(){
  const arr=filteredRecords().sort((a,b)=>b.date.localeCompare(a.date)); const body=document.getElementById("reportTable");
  body.innerHTML=arr.map(r=>{const s=studentById(r.studentId),c=criterionById(r.criterionId);return `<tr><td>${esc(r.date)}</td><td>${esc(s?.name||"-")}</td><td>${esc(s?.className||"-")}</td><td>${esc(c?.name||"-")}</td><td>${r.points}</td><td>${esc(r.note||"")}</td></tr>`}).join("");
  const students=new Set(arr.map(r=>r.studentId)); const pts=arr.reduce((a,b)=>a+(+b.points||0),0);
  document.getElementById("reportSummary").innerHTML=`<div><span>عدد عمليات الرصد</span><b>${arr.length}</b></div><div><span>عدد الطالبات</span><b>${students.size}</b></div><div><span>إجمالي النقاط</span><b>${pts}</b></div>`;
}
function renderCriteriaManage(){
  const box=document.getElementById("criteriaManage");
  box.innerHTML=state.criteria.map(c=>`<div class="card criteria-card"><span class="ico"><i data-lucide="${esc(c.icon)}"></i></span><div class="text"><h4>${esc(c.name)}</h4><p>${c.points} نقاط • ${esc(c.icon)}</p></div><div class="row-actions"><button class="mini-btn" onclick="editCriterion('${c.id}')"><i data-lucide="pencil"></i></button><button class="mini-btn danger" onclick="deleteCriterion('${c.id}')"><i data-lucide="trash-2"></i></button></div></div>`).join("");
}
function renderCertificate(){
  const sid=document.getElementById("certStudent").value, s=studentById(sid);
  document.getElementById("certStudentName").textContent=s?.name||"اسم الطالبة";
  document.getElementById("certPoints").textContent=s?score(s.id):0;
  document.getElementById("certReasonText").textContent=document.getElementById("certReason").value||"لتميزها في السلوك الإيجابي والمشاركة الفاعلة";
}

function modal(title,html){document.getElementById("modalTitle").textContent=title;document.getElementById("modalBody").innerHTML=html;document.getElementById("modal").classList.remove("hidden");lucide.createIcons()}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
document.getElementById("closeModal").onclick=closeModal;document.getElementById("modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});

document.getElementById("addStudentBtn").onclick=()=>modal("إضافة طالبة",`<div class="form-card"><div class="field"><label>اسم الطالبة</label><input id="mName" autofocus></div><div class="field"><label>الفصل</label><select id="mClass">${state.classes.map(c=>`<option>${esc(c)}</option>`).join("")}</select></div><button class="btn primary full" onclick="saveStudent()">حفظ</button></div>`);
window.saveStudent=function(editId=null){const name=document.getElementById("mName").value.trim(),cl=document.getElementById("mClass").value;if(!name)return toast("اكتبي اسم الطالبة");if(editId){const s=studentById(editId);s.name=name;s.className=cl}else state.students.push({id:id(),name,className:cl});save();closeModal();renderAll();toast("تم الحفظ");lucide.createIcons()}
window.editStudent=function(x){const s=studentById(x);modal("تعديل الطالبة",`<div class="form-card"><div class="field"><label>اسم الطالبة</label><input id="mName" value="${esc(s.name)}"></div><div class="field"><label>الفصل</label><select id="mClass">${state.classes.map(c=>`<option ${c===s.className?"selected":""}>${esc(c)}</option>`).join("")}</select></div><button class="btn primary full" onclick="saveStudent('${x}')">حفظ التعديل</button></div>`)}
window.deleteStudent=function(x){if(confirm("حذف الطالبة وجميع عمليات الرصد الخاصة بها؟")){state.students=state.students.filter(s=>s.id!==x);state.records=state.records.filter(r=>r.studentId!==x);save();renderAll();toast("تم الحذف");lucide.createIcons()}}
document.getElementById("bulkAddBtn").onclick=()=>modal("لصق قائمة طالبات",`<div class="form-card"><div class="field"><label>الفصل</label><select id="mClass">${state.classes.map(c=>`<option>${esc(c)}</option>`).join("")}</select></div><div class="field"><label>الأسماء - اسم في كل سطر</label><textarea id="mBulk" rows="12" placeholder="سارة أحمد\nفاطمة علي\n..."></textarea></div><button class="btn primary full" onclick="saveBulk()">إضافة القائمة</button></div>`);
window.saveBulk=function(){const cl=document.getElementById("mClass").value,names=document.getElementById("mBulk").value.split(/\n+/).map(x=>x.trim()).filter(Boolean);names.forEach(name=>state.students.push({id:id(),name,className:cl}));save();closeModal();renderAll();toast(`تمت إضافة ${names.length} طالبة`);lucide.createIcons()}
document.getElementById("addClassBtn").onclick=()=>modal("إضافة فصل / شعبة",`<div class="form-card"><div class="field"><label>اسم الفصل</label><input id="mClassName" placeholder="مثال: 2/5"></div><button class="btn primary full" onclick="saveClass()">حفظ</button></div>`);
window.saveClass=function(){const x=document.getElementById("mClassName").value.trim();if(x&&!state.classes.includes(x)){state.classes.push(x);save();closeModal();renderAll();toast("تمت إضافة الفصل");lucide.createIcons()}}

document.getElementById("saveRecordBtn").onclick=()=>{const sid=document.getElementById("recordStudent").value,c=criterionById(selectedCriterion);if(!sid)return toast("اختاري طالبة");if(!c)return toast("اختاري معيارًا");state.records.push({id:id(),studentId:sid,criterionId:c.id,points:c.points,date:document.getElementById("recordDate").value||today(),note:document.getElementById("recordNote").value.trim()});document.getElementById("recordNote").value="";save();renderAll();toast("تم حفظ الرصد");lucide.createIcons()}
window.deleteRecord=function(x){if(confirm("حذف عملية الرصد؟")){state.records=state.records.filter(r=>r.id!==x);save();renderAll();toast("تم الحذف");lucide.createIcons()}}

document.getElementById("addCriterionBtn").onclick=()=>criterionModal();
function criterionModal(c){modal(c?"تعديل معيار":"معيار جديد",`<div class="form-card"><div class="field"><label>اسم المعيار</label><input id="mCritName" value="${esc(c?.name||"")}"></div><div class="field"><label>النقاط</label><input id="mCritPoints" type="number" min="1" value="${c?.points||5}"></div><div class="field"><label>اسم أيقونة Lucide</label><input id="mCritIcon" value="${esc(c?.icon||"star")}"><small class="muted">أمثلة: star, heart, trophy, hand, rocket, shield-check</small></div><button class="btn primary full" onclick="saveCriterion('${c?.id||""}')">حفظ</button></div>`)}
window.editCriterion=function(x){criterionModal(criterionById(x))}
window.saveCriterion=function(x){const name=document.getElementById("mCritName").value.trim(),points=+document.getElementById("mCritPoints").value||5,icon=document.getElementById("mCritIcon").value.trim()||"star";if(!name)return toast("اكتبي اسم المعيار");if(x){Object.assign(criterionById(x),{name,points,icon})}else{const n={id:id(),name,points,icon};state.criteria.push(n);selectedCriterion=n.id}save();closeModal();renderAll();toast("تم حفظ المعيار");lucide.createIcons()}
window.deleteCriterion=function(x){if(confirm("حذف المعيار؟ عمليات الرصد القديمة ستبقى دون اسم المعيار.")){state.criteria=state.criteria.filter(c=>c.id!==x);if(selectedCriterion===x)selectedCriterion=state.criteria[0]?.id||null;save();renderAll();lucide.createIcons()}}

document.querySelectorAll(".nav-link").forEach(b=>b.onclick=()=>goPage(b.dataset.page));
document.getElementById("menuBtn").onclick=()=>document.getElementById("sidebar").classList.toggle("open");
document.getElementById("quickRecordBtn").onclick=()=>goPage("record");
document.getElementById("backupBtn").onclick=()=>downloadBackup();
document.getElementById("downloadBackupBtn").onclick=()=>downloadBackup();

function downloadBackup(){const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="behavior-tracker-backup.json";a.click();URL.revokeObjectURL(a.href);toast("تم تنزيل النسخة الاحتياطية")}
document.getElementById("restoreInput").onchange=e=>{const f=e.target.files[0];if(!f)return;const rd=new FileReader();rd.onload=()=>{try{state=JSON.parse(rd.result);save();renderAll();toast("تمت استعادة البيانات");lucide.createIcons()}catch{toast("ملف النسخة غير صالح")}};rd.readAsText(f)}
document.getElementById("resetDataBtn").onclick=()=>{if(confirm("سيتم حذف جميع البيانات نهائيًا من هذا الجهاز. متابعة؟")){state=structuredClone(defaults);save();renderAll();toast("تمت إعادة الضبط");lucide.createIcons()}}
document.getElementById("saveSettingsBtn").onclick=()=>{state.settings={school:document.getElementById("settingSchool").value.trim()||defaults.settings.school,teacher:document.getElementById("settingTeacher").value.trim(),principal:document.getElementById("settingPrincipal").value.trim(),year:document.getElementById("settingYear").value.trim()};save();renderAll();toast("تم حفظ الإعدادات");lucide.createIcons()}

document.getElementById("recordClass").onchange=()=>{fillStudentsForRecord()};
document.getElementById("studentClassFilter").onchange=renderStudents;document.getElementById("studentSearch").oninput=renderStudents;
document.getElementById("reportClass").onchange=()=>{fillReportStudents();renderReports()};document.getElementById("reportStudent").onchange=renderReports;document.getElementById("reportFrom").onchange=renderReports;document.getElementById("reportTo").onchange=renderReports;
document.getElementById("certClass").onchange=fillCertStudents;document.getElementById("certStudent").onchange=renderCertificate;document.getElementById("certReason").oninput=renderCertificate;
document.getElementById("printReportBtn").onclick=()=>{goPage("reports");setTimeout(()=>window.print(),100)};
document.getElementById("printCertificateBtn").onclick=()=>{goPage("certificates");setTimeout(()=>window.print(),100)};
document.getElementById("exportCsvBtn").onclick=()=>{const rows=[["التاريخ","الطالبة","الفصل","السلوك","النقاط","الملاحظة"],...filteredRecords().map(r=>{const s=studentById(r.studentId),c=criterionById(r.criterionId);return [r.date,s?.name||"",s?.className||"",c?.name||"",r.points,r.note||""]})];const csv="\ufeff"+rows.map(row=>row.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"}));a.download="behavior-report.csv";a.click();URL.revokeObjectURL(a.href)}
document.getElementById("recordDate").value=today();
document.getElementById("todayText").textContent=new Intl.DateTimeFormat("ar-SA",{dateStyle:"full"}).format(new Date());

renderAll();lucide.createIcons();
